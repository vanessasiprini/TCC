Voluntarios 

insert into voluntario (nome, cpf, genero, data_nasci, email)
values
('Vagaogurz','735.393.710-60','masculino','1979-03-06','vagaogsdg34@gmail.com'),

('Lucas Vinicius Silveira','738.129.570-94','masculino','1999-03-09','lucasviniciussilveira-85@buzatto.pro'),

('Carlos S�rgio Apar�cio','086.053.575-41','masculino','1998-09-10','carlossergioaparicio-87@dyna.com.br'),

('Isis Luzia da Rosa','814.518.968-32','feminino','2000-04-30','isisluziadarosa_@cancaonova.com'),

('Andr� Leandro Gon�alves','676.769.320-09','masculino','1995-09-12','aandreleandrogoncalves@2registrocivil.com.br'),

('Antonio Guilherme Bryan Ferreira','894.3.568-02','masculino','1989-09-08','antonioguilhermebryanferreira@soupelli.com.br'),

('Rita M�rcia Pires','493.383.193-93','feminino','1987-06-19','rritamarciapires@negleribeiro.com'),

('Kevin Lorenzo Peixoto','234.567.987-09','masculino','1970-11-24','kevinlorenzopeixoto_@santander.com.br'),

('Matheus Henrique Barros','940.813.091-08','masculino','1997-10-27','mmatheushenriquebarros@segplanet.com.br'),

('Francisco Caio Vieira','438.416.654-03','masculino','1988-09-30','franciscocaiovieira__franciscocaiovieira@terapeutaholistica.com.br'),

('Gabriel Gustavo Paulo da Paz','307.518.819-02','masculino','1999-09-20','gabrielgustavopaulodapaz_@edepbr.com.br'),

('Regina Mariah da Mota','482.090.281-46','feminino','1997-09-07','reginamariahdamota..reginamariahdamota@babo.adv.br'),

('Catarina Juliana Gomes','605.264.212-23','feminino','1984-05-12','catarinajulianagomes_@knowconsulting.com.br'),

('Manoel Juan Oliveira','924.541.561-99','masculino','2000-02-11','manoeljuanoliveira-70@hospitalprovisao.org.br'),

('Rodrigo Iago Souza','966.594.872-55','masculino','1987-03-23','rodrigoiagosouza-70@andrelam.com.br'),

('Juliana Alana Baptista','885.347.315-00','feminino','1994-08-29','julianaalanabaptista..julianaalanabaptista@maccropropaganda.com.br'),

('Allana Juliana Arag�o','503.656.785-46','feminino','1989-03-29','hheloisaterezarocha@w3ag.com'),

('Joana Martins','896.882.089-90','feminino','1999-07-26','joanammm@deze7.com.br'),

('Bernardo Vitor Fernando da Silva','548.898.027-03','masculino','1999-07-29','bernardovitorfernandodasilva..bernardovitorfernandodasilva@gm.com'),

('Isaac Pedro da Concei��o','785.419.911-64','masculino','1995-02-29','isaacpedrodaconceicao..isaacpedrodaconceicao@dhl.com'),	

('F�tima Ana Mariane Apar�cio','006.392.167-73','feminino','1993-03-03','ffatimaanamarianeaparicio@betti.com.br'),	

('Levi Lu�s Sebasti�o Silveira','383.382.191-42','masculino','1991-01-01','lleviluissebastiaosilveira@iclud.com'),

('Luzia Clara Julia Apar�cio','772.683.803-56','feminino','1997-07-22','luziaclarajuliaaparicio_@vick1.com.br'),
('Nathan Arthur Emanuel da Costa','692.261.907-20','masculino','1992-06-21','nathanarthuremanueldacosta__nathanarthuremanueldacosta@planicoop.com.br'),

('Renato Gabriel Thales Ramos','883.236.573-19','masculino','1999-01-01','renatogabrielthalesramos..renatogabrielthalesramos@hawk.com.br'),

('Sophia Heloisa Mirella Gon�alves','977.488.487-69','feminino','1999-09-19','sophiaheloisamirellagoncalves..sophiaheloisamirellagoncalves@globo.com'),

('Marlene Sueli Oliveira','008.141.028-08','feminino','1994-03-10','marlenesuelioliveira_@unitau.br'),

('Henry Severino Pedro Assis','250.575.893-00','masculino','1987-09-09','hhenryseverinopedroassis@crbrandao.com.br'),	

('Valentina Sophia Vanessa Souza','206.030.990-50','feminino','1983-02-29','vakentianSophia@gmail.com'),

('Vera Vit�ria Gabrielly Barbosa','047.053.795-78','feminino','1989-02-02','vveravitoriagabriellybarbosa@baltico.com.br');		

Institui��o 

insert into (cnpj,usuario,nome,tipo_inst,logradouro,cep,descri,quant_abrig,email,nome_resp,cpf,senha)values
('53.533.381/0001-30','ABD_batista','Abdon Batista','orfanato','Rua Afonso Pena - 680','89202420','.....','20','andreamafio@yahoo.com.br','Andr� Maia','125.876.145-90','mbdhewhb'),
('12.619.491/0001-32','AbrigoInfanto','Abrigo Infanto Juvenil','orfanato',' Rua Padre Kolb - 1449','89202145','','18','abrigoinfantojuvenil.projetos@gmail.com','Maria Fernada','987.654.456-09','resdzgth'),
('40.378.387/0001-39','CasaLar_AAV','Casa Lar Emanuel - Associa��o �gua da Vida','orfanato','Rua Padre Roma - 339','89230210','','15','adm@laremauel.org.br','Laura Silva','098.456.854-89','kijuhyrt'),
('93.375.389/0001-30','Casa_BR','Casa de Repouso Bom Retiro','asilo','Rua Rio Negro - 293 ','49045-110','','30','bomretirolar@gmail.com','Joana Rubens','654.654.876-09','vascdcac'),
('99.107.993/0001-62','LAR_casa','Casa De Repouso Lar ','asilo','Rua Macedo - 234','64603-165','','18','larderepousobom.12@gmail.com','Mario Costa','098.876.965-87','fedwc'),
('08.360.872/0001-72','SM_lar','Lar S�o Miguel','asilo','Rua Jo�o costa - 123','56506-410','','26','larlarlar@bol.com.br','Felipe Jos�','956.654.837-45','eqawecrv');

Demanda

insert into (tipo_deman,nome,quant, modelo,descri_doa)values
('roupa','cal�a','5','jeans','para crian�as de 5 a 10 anos'),
('roupa','casaco','3','moletom','tamanho GG - feminino ou masculino'),
('produto de limpeza','sab�o em p�','2','',''),
('brinquedo','jogos educativos','4','infantil',''),
('alimento','arroz','5','',''),
('alimento','bolacha','8','maizena','para o lanche das crian�as'),
('produto de higiene','escova de dente','3','',''),
('m�vel','cama','1','solteiro',''),
('outros','len�ol','5','cama de solteiro','para as novas camas dos idosos');

Doa��o

insert into doacao (tipo_doa, nome, quant_doa, modelo, descri_doa, doador)values 
('brinquedo','boneca','2','barbie','','Joana Maria'),
('roupa','camisa','5','polo','tamanho M',''),
('cal�ado','t�nis','1','esporte','tamanho 38 - feminino','Claudia Santos'),
('produto de limpeza','amaciante','2','','','Jo�o Paulo'),
('brinquedo','jogos educativos','4','infantil','novos','M�rcio'),
('alimento','leite','12','caixa','','meracdo s�o mario'),
('alimento','bolacha','8','maizena','','Jaqueline'),
('produto de higiene','papel higienico','24','','',''),
('m�vel','guarda-roupa','1','6 postas','azul com carrinhos desenhado','Patricio Moraes'),
('outros','maquiagem','18','batom,r�mel e base','diversas marcas e cores','Ana maria do blog faz de conta');
