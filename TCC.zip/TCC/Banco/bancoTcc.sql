create table Instituicao(
	cnpj int not null primary key,
	usuario varchar(30) not null,
	nome varchar(30) not null,
    	tipo_inst enum('orfanato','asilo') not null,
	logradouro varchar(80) not null,
	cep int not null,
	descri varchar(1000),
	quant_abrig int not null,
	email varchar(50)not null,
	nome_resp varchar(30) not null,
	cpf int not null,
	senha varchar(30) not null
);


create table doacao(
	cod_doa int not null primary key auto_increment,
	tipo_doa enum('roupa','alimento','produto de limpeza','produto de higiene','cal�ado','brinqudeo','m�vel','outros') not null, /*como alterar para enum*/
	nome varchar(30) not null,
	quant_doa int not null,
    	modelo varchar(30),
	descri_doa varchar(100),
	doador varchar(30)
);

create table demanda(
	cod_deman int not null primary key auto_increment,
	tipo_deman enum('roupa','alimento','produto de limpeza','produto de higiene','cal�ado','brinqudeo','m�vel','outros') not null,
	nome varchar(30) not null,
	quant_dia int not null,
	modelo varchar(30),
	descri_doa varchar(100),
);


create table voluntario(
	nome varchar(30) not null,
	cpf varchar(17) primary key not null,
	genero enum('masculino','feminino','n�o definido'),
	data_nasci date not null,
	email varchar(60) not null,
	senha varchar(20) not null

);


/*quantDoa: a quantidade que precisa de doacao.... doaDemanda: a quantidade ja doada*/





	

















