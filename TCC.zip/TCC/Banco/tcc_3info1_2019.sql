-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 26-Jun-2019 às 18:43
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.1.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tcc_3info1_2019`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `demanda`
--

CREATE TABLE `demanda` (
  `cod_deman` int(11) NOT NULL,
  `tipo_deman` enum('roupa','alimento','produto de limpeza','produto de higiene','calçado','brinquedo','móvel','outros') NOT NULL,
  `nome` varchar(30) NOT NULL,
  `quant` int(11) NOT NULL,
  `modelo` varchar(30) DEFAULT NULL,
  `descri_doa` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `demanda`
--

INSERT INTO `demanda` (`cod_deman`, `tipo_deman`, `nome`, `quant`, `modelo`, `descri_doa`) VALUES
(1, 'roupa', 'calça', 5, 'jeans', 'para crianças de 5 a 10 anos'),
(2, 'roupa', 'casaco', 3, 'moletom', 'tamanho GG - feminino ou masculino'),
(3, 'produto de limpeza', 'sabão em pó', 2, '', ''),
(4, '', 'jogos educativos', 4, 'infantil', ''),
(5, 'alimento', 'arroz', 5, '', ''),
(6, 'alimento', 'bolacha', 8, 'maizena', 'para o lanche das crianças'),
(7, 'produto de higiene', 'escova de dente', 3, '', ''),
(8, 'móvel', 'cama', 1, 'solteiro', ''),
(9, 'outros', 'lençol', 5, 'cama de solteiro', 'para as novas camas dos idosos');

-- --------------------------------------------------------

--
-- Estrutura da tabela `doacao`
--

CREATE TABLE `doacao` (
  `cod_doa` int(11) NOT NULL,
  `tipo_doa` enum('roupa','alimento','produto de limpeza','produto de higiene','calçado','brinquedo','móvel','outros') NOT NULL,
  `nome` varchar(30) NOT NULL,
  `quant_doa` int(11) NOT NULL,
  `modelo` varchar(30) DEFAULT NULL,
  `descri_doa` varchar(100) DEFAULT NULL,
  `doador` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `doacao`
--

INSERT INTO `doacao` (`cod_doa`, `tipo_doa`, `nome`, `quant_doa`, `modelo`, `descri_doa`, `doador`) VALUES
(1, '', 'boneca', 2, 'barbie', '', 'Joana Maria'),
(2, 'roupa', 'camisa', 5, 'polo', 'tamanho M', ''),
(3, 'calçado', 'tênis', 1, 'esporte', 'tamanho 38 - feminino', 'Claudia Santos'),
(4, 'produto de limpeza', 'amaciante', 2, '', '', 'João Paulo'),
(5, '', 'jogos educativos', 4, 'infantil', 'novos', 'Márcio'),
(6, 'alimento', 'leite', 12, 'caixa', '', 'meracdo são mario'),
(7, 'alimento', 'bolacha', 8, 'maizena', '', 'Jaqueline'),
(8, 'produto de higiene', 'papel higienico', 24, '', '', ''),
(9, 'móvel', 'guarda-roupa', 1, '6 postas', 'azul com carrinhos desenhado', 'Patricio Moraes'),
(10, 'outros', 'maquiagem', 18, 'batom,rímel e base', 'diversas marcas e cores', 'Ana maria do blog faz de conta');

-- --------------------------------------------------------

--
-- Estrutura da tabela `instituicoes`
--

CREATE TABLE `instituicoes` (
  `cnpj` varchar(30) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `nome` varchar(30) NOT NULL,
  `tipo_inst` enum('orfanato','asilo') NOT NULL,
  `logradouro` varchar(80) NOT NULL,
  `cep` varchar(10) NOT NULL,
  `descri` varchar(1000) DEFAULT NULL,
  `quant_abrig` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nome_resp` varchar(30) NOT NULL,
  `cpf` varchar(18) NOT NULL,
  `senha` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `instituicoes`
--

INSERT INTO `instituicoes` (`cnpj`, `usuario`, `nome`, `tipo_inst`, `logradouro`, `cep`, `descri`, `quant_abrig`, `email`, `nome_resp`, `cpf`, `senha`) VALUES
('07.330.872/0001-72	', '@ytiiuore', 'cristiane rodrigues da silva s', 'asilo', 'rua jordania', '89245-000', 'cdder', 5, 'vanessasipriani15@gmail.com', 'cristiane rodrigues da silva s', '124.761.609-62', '34321'),
('12.619.491/0001-32', 'AbrigoInfanto', 'Abrigo Infanto Juvenil', 'orfanato', ' Rua Padre Kolb - 1449', '89202145', '', 18, 'abrigoinfantojuvenil.projetos@gmail.com', 'Maria Fernada', '987.654.456-09', 'resdzgth'),
('40.378.387/0001-39', 'CasaLar_AAV', 'Casa Lar Emanuel - Associação ', 'orfanato', 'Rua Padre Roma - 339', '89230210', '', 15, 'adm@laremauel.org.br', 'Laura Silva', '098.456.854-89', 'kijuhyrt'),
('4554543345', '@ytiiuore', 'cristiane rodrigues da silva s', 'orfanato', 'rua jordania', '89245-000', '', 1, 'vanessasipriani15@gmail.com', '', '', 'f'),
('53.533.381/0001-30', 'ABD_batista', 'Abdon Batista', 'orfanato', 'Rua Afonso Pena - 680', '89202420', '.....', 20, 'andreamafio@yahoo.com.br', 'André Maia', '125.876.145-90', 'mbdhewhb'),
('93.375.389/0001-30', 'Casa_BR', 'Casa de Repouso Bom Retiro', 'asilo', 'Rua Rio Negro - 293 ', '49045', '', 30, 'bomretirolar@gmail.com', 'Joana Rubens', '654.654.876-09', 'vascdcac'),
('99.107.993/0001-62', 'LAR_casa', 'Casa De Repouso Lar ', 'asilo', 'Rua Macedo - 234', '64603', '', 18, 'larderepousobom.12@gmail.com', 'Mario Costa', '098.876.965-87', 'fedwc');

-- --------------------------------------------------------

--
-- Estrutura da tabela `voluntario`
--

CREATE TABLE `voluntario` (
  `nome` varchar(30) NOT NULL,
  `cpf` varchar(17) NOT NULL,
  `genero` enum('masculino','feminino','não definido') NOT NULL,
  `data_nasci` date NOT NULL,
  `email` varchar(60) NOT NULL,
  `senha` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `voluntario`
--

INSERT INTO `voluntario` (`nome`, `cpf`, `genero`, `data_nasci`, `email`, `senha`) VALUES
('Fátima Ana Mariane Aparício', '006.392.167-73', 'feminino', '1993-03-03', 'ffatimaanamarianeaparicio@betti.com.br', ''),
('Marlene Sueli Oliveira', '008.141.028-08', 'feminino', '1994-03-10', 'marlenesuelioliveira_@unitau.br', ''),
('Vera Vitória Gabrielly Barbosa', '047.053.795-78', 'feminino', '1989-02-02', 'vveravitoriagabriellybarbosa@baltico.com.br', ''),
('Carlos Sérgio Aparício', '086.053.575-41', 'masculino', '1998-09-10', 'carlossergioaparicio-87@dyna.com.br', ''),
('Valentina Sophia Vanessa Souza', '206.030.990-50', 'feminino', '0000-00-00', 'vakentianSophia@gmail.com', ''),
('Kevin Lorenzo Peixoto', '234.567.987-09', 'masculino', '1970-11-24', 'kevinlorenzopeixoto_@santander.com.br', ''),
('Henry Severino Pedro Assis', '250.575.893-00', 'masculino', '1987-09-09', 'hhenryseverinopedroassis@crbrandao.com.br', ''),
('Gabriel Gustavo Paulo da Paz', '307.518.819-02', 'masculino', '1999-09-20', 'gabrielgustavopaulodapaz_@edepbr.com.br', ''),
('Levi Luís Sebastião Silveira', '383.382.191-42', 'masculino', '1991-01-01', 'lleviluissebastiaosilveira@iclud.com', ''),
('Francisco Caio Vieira', '438.416.654-03', 'masculino', '1988-09-30', 'franciscocaiovieira__franciscocaiovieira@terapeutaholistica.', ''),
('Regina Mariah da Mota', '482.090.281-46', 'feminino', '1997-09-07', 'reginamariahdamota..reginamariahdamota@babo.adv.br', ''),
('Rita Márcia Pires', '493.383.193-93', 'feminino', '1987-06-19', 'rritamarciapires@negleribeiro.com', ''),
('Allana Juliana Aragão', '503.656.785-46', 'feminino', '1989-03-29', 'hheloisaterezarocha@w3ag.com', ''),
('Bernardo Vitor Fernando da Sil', '548.898.027-03', 'masculino', '1999-07-29', 'bernardovitorfernandodasilva..bernardovitorfernandodasilva@g', ''),
('Catarina Juliana Gomes', '605.264.212-23', 'feminino', '1984-05-12', 'catarinajulianagomes_@knowconsulting.com.br', ''),
('André Leandro Gonçalves', '676.769.320-09', 'masculino', '1995-09-12', 'aandreleandrogoncalves@2registrocivil.com.br', ''),
('Nathan Arthur Emanuel da Costa', '692.261.907-20', 'masculino', '1992-06-21', 'nathanarthuremanueldacosta__nathanarthuremanueldacosta@plani', ''),
('Vagaogurz', '735.393.710-60', 'masculino', '1979-03-06', 'vagaogsdg34@gmail.com', ''),
('Lucas Vinicius Silveira', '738.129.570-94', 'masculino', '1999-03-09', 'lucasviniciussilveira-85@buzatto.pro', ''),
('Luzia Clara Julia Aparício', '772.683.803-56', 'feminino', '1997-07-22', 'luziaclarajuliaaparicio_@vick1.com.br', ''),
('Isaac Pedro da Conceição', '785.419.911-64', 'masculino', '0000-00-00', 'isaacpedrodaconceicao..isaacpedrodaconceicao@dhl.com', ''),
('Isis Luzia da Rosa', '814.518.968-32', 'feminino', '2000-04-30', 'isisluziadarosa_@cancaonova.com', ''),
('Renato Gabriel Thales Ramos', '883.236.573-19', 'masculino', '1999-01-01', 'renatogabrielthalesramos..renatogabrielthalesramos@hawk.com.', ''),
('Juliana Alana Baptista', '885.347.315-00', 'feminino', '1994-08-29', 'julianaalanabaptista..julianaalanabaptista@maccropropaganda.', ''),
('Joana Martins', '896.882.089-90', 'feminino', '1999-07-26', 'joanammm@deze7.com.br', ''),
('Manoel Juan Oliveira', '924.541.561-99', 'masculino', '2000-02-11', 'manoeljuanoliveira-70@hospitalprovisao.org.br', ''),
('Matheus Henrique Barros', '940.813.091-08', 'masculino', '1997-10-27', 'mmatheushenriquebarros@segplanet.com.br', ''),
('Rodrigo Iago Souza', '966.594.872-55', 'masculino', '1987-03-23', 'rodrigoiagosouza-70@andrelam.com.br', ''),
('Sophia Heloisa Mirella Gonçalv', '977.488.487-69', 'feminino', '1999-09-19', 'sophiaheloisamirellagoncalves..sophiaheloisamirellagoncalves', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `demanda`
--
ALTER TABLE `demanda`
  ADD PRIMARY KEY (`cod_deman`);

--
-- Indexes for table `doacao`
--
ALTER TABLE `doacao`
  ADD PRIMARY KEY (`cod_doa`);

--
-- Indexes for table `instituicoes`
--
ALTER TABLE `instituicoes`
  ADD PRIMARY KEY (`cnpj`);

--
-- Indexes for table `voluntario`
--
ALTER TABLE `voluntario`
  ADD PRIMARY KEY (`cpf`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `demanda`
--
ALTER TABLE `demanda`
  MODIFY `cod_deman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `doacao`
--
ALTER TABLE `doacao`
  MODIFY `cod_doa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
