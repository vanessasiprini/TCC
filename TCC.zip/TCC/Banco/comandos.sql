select * from nome = mostar todos os dados da tabela 

RENAME TABLE tb1 TO tb2; = renomear tabela

alter table teste change campo1 campox varchar(100),= renomear coluna

alter table nome add column nome e as coisas = adicionar coluna

O comando update possui a sintaxe muito similar ao do INSERT, mas � utilizada para atualizar registros do banco de dados.

UPDATE NOME_DA_TABELA SET campo1 = valor1, campo2 = valor2.
UPDATE clientes SET nome = 'Rafael', email = 'contato@rlsystem.com.br';

DELETE FROM NOME_DA_TABELA WHERE id = VALOR_DO_ID;

Exemplo:

DELETE FROM clientes WHERE id = 1;

Nota 1: desta forma, voc� estar� excluindo o registro que conter o id 1.




delete from doacao where cod_doa = '2';


ALTER TABLE demanda DROP COLUMN tipo_dema;
select * from demanda;

explain instituicao;


alter table doacao modify modelo varchar(30) not null;


insert into usuario (nome_user, cpf, email, senha)values('Vagaogurz','735.393.710-60','vagaogsdg34@gmail.com','looshuunjceb'),
('Lucas Vinicius Silveira','738.129.570-94','lucasviniciussilveira-85@buzatto.pro','LLkDT1A0iB'),
('Carlos S�rgio Apar�cio','086.053.575-41','carlossergioaparicio-87@dyna.com.br','9l2poXBMKj'),
('Isis Luzia da Rosa','814.518.968-32','isisluziadarosa_@cancaonova.com','oaRG8d84I0'),
('Andr� Leandro Gon�alves','676.769.320-09','aandreleandrogoncalves@2registrocivil.com.br','K3pxqXtBmy'),
('Antonio Guilherme Bryan Ferreira','682.875.104-30','antonioguilhermebryanferreira@soupelli.com.br','Orxbji8rid'),
('Rita M�rcia Pires','493.383.193-93','rritamarciapires@negleribeiro.com','uhdHracHFk'),
('Kevin Lorenzo Peixoto','234.567.987-09','kevinlorenzopeixoto_@santander.com.br','L9LitXh5xF'),
('Matheus Henrique Barros','940.813.091-08','mmatheushenriquebarros@segplanet.com.br','CQNDHZcJUj'),
('Francisco Caio Vieira','438.416.654-03','franciscocaiovieira__franciscocaiovieira@terapeutaholistica.com.br','gcaZ5kFgGe'),
('Gabriel Gustavo Paulo da Paz','307.518.819-02','gabrielgustavopaulodapaz_@edepbr.com.br','YMGKwOCkY9'),
('Regina Mariah da Mota','482.090.281-46','reginamariahdamota..reginamariahdamota@babo.adv.br','b7mqAlrPby'),
('Catarina Juliana Gomes','605.264.212-23','catarinajulianagomes_@knowconsulting.com.br','5sMc6z5J8H'),
('Manoel Juan Oliveira','924.541.561-99','manoeljuanoliveira-70@hospitalprovisao.org.br','xRENzgZZKg'),
('Rodrigo Iago Souza','966.594.872-55','rodrigoiagosouza-70@andrelam.com.br','CriqMcIGNW'),
('Juliana Alana Baptista','885.347.315-00','julianaalanabaptista..julianaalanabaptista@maccropropaganda.com.br','pOuNjP54cg'),
('Allana Juliana Arag�o','503.656.785-46','hheloisaterezarocha@w3ag.com','JnwdQTGENn'),
('Joana Martins','896.882.089-90','joanammm@deze7.com.br','2KuFNnCaJw'),
('Bernardo Vitor Fernando da Silva','548.898.027-03','bernardovitorfernandodasilva..bernardovitorfernandodasilva@gm.com','3bnrRhgTuR'),
('Isaac Pedro da Concei��o','785.419.911-64','isaacpedrodaconceicao..isaacpedrodaconceicao@dhl.com','ZEnTAud0SQ'),	
('F�tima Ana Mariane Apar�cio','006.392.167-73','ffatimaanamarianeaparicio@betti.com.br','ca6qlhaLNx'),	
('Levi Lu�s Sebasti�o Silveira','383.382.191-42','lleviluissebastiaosilveira@iclud.com','UzZdHYI0kC'),
('Luzia Clara Julia Apar�cio','772.683.803-56','luziaclarajuliaaparicio_@vick1.com.br','9GdU4gqDYb'),
('Nathan Arthur Emanuel da Costa','692.261.907-20','nathanarthuremanueldacosta__nathanarthuremanueldacosta@planicoop.com.br','mBl0QO8NTt'),
('Renato Gabriel Thales Ramos','883.236.573-19','renatogabrielthalesramos..renatogabrielthalesramos@hawk.com.br','SLQ4uBN6xI'),
('Sophia Heloisa Mirella Gon�alves','977.488.487-69','sophiaheloisamirellagoncalves..sophiaheloisamirellagoncalves@globo.com','QydEOT2nJk'),
('Marlene Sueli Oliveira','008.141.028-08','marlenesuelioliveira_@unitau.br','Qgxo4FWJBN'),
('Henry Severino Pedro Assis','250.575.893-00','hhenryseverinopedroassis@crbrandao.com.br','1GqaAnsLHz'),		
('Valentina Sophia Vanessa Souza','206.030.990-50','vakentianSophia@gmail.com','87y787ffr'),	
('Vera Vit�ria Gabrielly Barbosa','047.053.795-78','vveravitoriagabriellybarbosa@baltico.com.br','XLsJMRg7RB');		


insert into doacao (quant_doa, tipo_doa, modelo, descri_doa)values('3','roupa','cal�a','cal�a infantil');


alter table demanda add column nome varchar(30) not null;
