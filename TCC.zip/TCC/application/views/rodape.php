    <div class="snackbars" id="form-output-global"></div>
    <script src="assets/js/core.min.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="assets/bootstrap/dist/js/bootstrap.js"></script>
    <script src="assets/popper.js/dist/umd/popper.js"></script>
    <!-- coded by ragnar-->
  </body>
</html>

<?php
  include('rodape.php');
?>