<?php
  include('cabeçalho.php');
?>
<div class="tabela" style="padding-top: 100px;padding-right: 30px;padding-left: 30px;">
          <!-- Button trigger modal -->
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                Cadastrar nova instituição
              </button>

              <!-- Modal -->
              <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Nova Instituição</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="<?php echo site_url('InstituicoesController/create')?>">
                            <div class="form-group">
                              <label for="cnpj" required >Cnpj</label>
                              <input type="text" class="form-control" name="cnpj" id='cnpj' placeholder="XX.XXX.XXX/XXXX-XX">
                            </div>
                             <div class="form-group">
                              <label for="usuario">Usuario</label>
                              <input type="text" class="form-control" name="usuario" placeholder="@exemplo">
                            </div>
                             <div class="form-group">
                              <label for="nome">Nome</label>
                              <input type="text" class="form-control" name="nome">
                            </div>
                            <div class="form-group">
                              <label for="tipo_inst">Tipo de Instituição</label>
                              <select class="form-control" name="tipo_inst">
                                <option>Orfanato</option>
                                <option>Asilo</option>
                              </select>
                            </div>
                             <div class="form-group">
                              <label for="logradouro">Logradouro</label>
                              <input type="text" class="form-control" name="logradouro" placeholder="Rua:XXXXXX N° XXX">
                            </div>
                             <div class="form-group">
                              <label for="cep">Cep</label>
                              <input type="text" class="form-control" name="cep" placeholder="XXXXX-XXX">
                            </div>
                            <div class="form-group">
                              <label for="descri">Descrição</label>
                              <textarea class="form-control" name="descri" rows="3"></textarea>
                            </div>
                            <!--colocar um proprio para numeros-->
                            <div class="form-group">
                              <label for="quant_abrig">Quantnameade de Abrigados</label>
                              <select class="form-control" name="quant_abrig">
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                              </select>
                            </div>
                            <div class="form-group">
                              <label for="email">Email</label>
                              <input type="email" class="form-control" name="email" placeholder="exemplo@tatat">
                            </div>
                            <div class="form-group">
                              <label for="nome_resp">Nome Responsavel</label>
                              <input type="text" class="form-control" name="nome_resp" placeholder="">
                            </div>
                            <div class="form-group">
                              <label for="cpf">Cpf</label>
                              <input type="text" class="form-control" name="cpf" placeholder="">
                            </div>
                            <div class="form-group">
                              <label for="senha">Senha</label>
                              <input type="password" class="form-control" name="senha" placeholder="">
                            </div>
                            <button type="submit" class="btn btn-primary" value="save">Submit</button>
                          </form>
                    </div>
                  </div>
                </div>
              </div>
          <table class="table">
            <thead class="thead-dark">
              <tr>
                  <th  scope="col">cnpj</th>
                  <th  scope="col">Usuario</th>
                  <th  scope="col">nome</th>
                  <th  scope="col">tipo_inst</th>
                  <th  scope="col">logradouro</th>
                  <th  scope="col">cep</th>
                  <th  scope="col">descri</th>
                  <th  scope="col">Quantidade de abrigados</th>
                  <th  scope="col">email</th>
                  <th  scope="col">nome_resp</th>
                  <th  scope="col">cpf</th>
                  <th  scope="col">senha</th>
                  <th  scope="col">açoes</th>

              </tr>
            </thead>
            <tbody>
              <?php foreach($result as $row) {?>
              <tr>
                <th scope="row"><?php echo $row->cnpj;?></th>
                <td><?php echo $row->usuario;?></td>
                <td><?php echo $row->nome;?></td>
                <td><?php echo $row->tipo_inst;?></td>
                <td><?php echo $row->logradouro;?></td>
                <td><?php echo $row->cep;?></td>
                <td><?php echo $row->descri;?></td>
                <td><?php echo $row->quant_abrig;?></td>
                <td><?php echo $row->email;?></td>
                <td><?php echo $row->nome_resp;?></td>
                <td><?php echo $row->cpf;?></td>
                <td><?php echo $row->senha;?></td>
                <td><a href="<?php echo site_url('InstituicoesController/Editar');?>/<?php echo $row->cnpj;?>">Editar</a>  | <a href="<?php echo site_url('InstituicoesController/Delete');?>/<?php echo $row->cnpj;?>">Deletar</a></td>

              </tr>
              <?php } ?>
            </tbody>
      </table>
</div>

<?php
  include('rodape.php');
?>