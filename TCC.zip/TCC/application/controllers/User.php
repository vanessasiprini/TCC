<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->helper('url');
$this->load->model('users_model');
}
public function index(){
//load session library
$this->load->library('session');
//restrict users to go back to login if session has been set
if($this->session->userdata('welcome')){
redirect('logado');
}
else{
$this->load->view('cabecalho');
}
}
public function login(){
//load session library
$this->load->library('session');
$usuario = $_POST['usuario'];
$senha = $_POST['senha'];
$data = $this->users_model->login($usuario, $senha);
if($data){
$this->session->set_userdata('welcome', $data);
redirect('logado');
}
else{
header('location:'.base_url().$this->index());
$this->session->set_flashdata('error','Login Invalido.User not found');
}
}
public function logado(){
//load session library
$this->load->library('session');
//restrict users to go to logado if not logged in
if($this->session->userdata('welcome')){
$this->load->view('logado');
}
else{
redirect('/');
}
}
public function logout(){
//load session library
$this->load->library('session');
$this->session->unset_userdata('welcome');
redirect('/');
}
}